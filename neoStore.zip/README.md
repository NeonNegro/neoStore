# Verdil

Loja SPA (React + Vite) com identidade escura premium e proposta de “bolsa botanica”: um catalogo para plantas ornamentais (curadoria para colecionadores), com vitrine, detalhe, autenticacao e rota protegida.

## Como rodar

```bash
npm install
npm run dev
```

## Credenciais de teste

- Usuario: `aluno`
- Senha: `1234`

Tambem e possivel criar uma nova conta na rota `/cadastro` (cadastro local salvo no navegador).

## Rotas

- `/` — catalogo (lista de produtos, busca e filtro por categoria)
- `/produto/:id` — detalhe do produto
- `/login` — login
- `/cadastro` — cadastro (simulacao local)
- `/minha-conta` — area protegida (redireciona para `/login` se nao estiver autenticado)
- `*` — pagina 404

## Funcionalidades implementadas

- Componentizacao (reutilizaveis)
  - `Layout` com `children`/`Outlet`, `Cabecalho`, `Rodape`, `Vitrine`, `ProdutoCard`, `Botao`, `Selo`
  - Renderizacao condicional e listas com `.map()`
- Estado, hooks e API
  - Consumo de produtos via DummyJSON
  - Estados de carregamento e erro
  - Busca por texto e filtro por categoria
- Navegacao SPA
  - React Router com lista, detalhe por `:id` e pagina 404
  - Clique no produto abre detalhe
- Autenticacao (simulada no front)
  - Login e cadastro com “API fake” (persistencia em `localStorage`)
  - Sessao em Context
  - Rota protegida e logout
- Bonus
  - Carrinho basico em Context (contagem no header e resumo na area protegida)

## Prints

Os prints ficam na pasta [screenshots](./screenshots).

### Catalogo

![Catalogo](./screenshots/catalogo.png)

### Detalhe

![Detalhe](./screenshots/detalhe.png)

### Login

![Login](./screenshots/login.png)

### Area protegida

![Minha conta](./screenshots/minha-conta.png)
